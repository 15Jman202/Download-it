//
//  AppDelegate.swift
//  Download-It
//
//  Created by Justin Carver on 9/27/16.
//  Copyright © 2016 Justin Carver. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject : AnyObject]?) -> Bool {
        return true
    }
}

